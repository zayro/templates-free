$('.style_green').click(function() {
	$('head').append('<link rel="stylesheet" href="assets/css/colours/green.css" type="text/css" />');
});
$('.style_blue').click(function() {
	$('head').append('<link rel="stylesheet" href="assets/css/colours/blue.css" type="text/css" />');
});
$('.style_red').click(function() {
		$('head').append('<link rel="stylesheet" href="assets/css/colours/red.css" type="text/css" />');
});
$('.style_turquoise').click(function() {
		$('head').append('<link rel="stylesheet" href="assets/css/colours/turquoise.css" type="text/css" />');
});
$('.style_turquoise2').click(function() {
		$('head').append('<link rel="stylesheet" href="assets/css/colours/turquoise2.css" type="text/css" />');
});
$('.style_purple').click(function() {
		$('head').append('<link rel="stylesheet" href="assets/css/colours/purple.css" type="text/css" />');
});
$('.style_orange').click(function() {
		$('head').append('<link rel="stylesheet" href="assets/css/colours/orange.css" type="text/css" />');
});
$('.style_brown').click(function() {
		$('head').append('<link rel="stylesheet" href="assets/css/colours/brown.css" type="text/css" />');
});
$('.style_black').click(function() {
		$('head').append('<link rel="stylesheet" href="assets/css/colours/black.css" type="text/css" />');
});