<?php
/*---------------------------------
	Main template.. it's just to help you get started
------------------------------------*/
get_header(); ?>


<?php get_footer(); ?>