<?php
/*
Template Name: Page with wide content (fullscreen)
*/
?>

    <?php

    get_template_part('templates/page', 'header');

    ?>

<div class="full-width">
    <?php

    get_template_part('templates/content', 'page');

    ?>
</div>
