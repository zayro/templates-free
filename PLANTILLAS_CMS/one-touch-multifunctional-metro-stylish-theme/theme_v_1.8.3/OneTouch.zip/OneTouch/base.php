<?php
?>
  <?php get_template_part('templates/header'); ?>
        <?php include roots_template_path(); ?>
  </div>
  </div>
  <?php get_template_part('templates/footer'); ?>


<?php wp_footer(); ?>
</body>
</html>
