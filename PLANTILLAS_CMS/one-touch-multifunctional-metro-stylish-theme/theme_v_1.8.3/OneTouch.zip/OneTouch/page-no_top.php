<?php
/*
Template Name: Page For Custom Layouts
*/
?>


<div class="row">

  <div id = "content" class = "fifteen columns" ><div class = "row" >


    <?php
        get_template_part('templates/content', 'page');
     ?>


  </div></div>

</div>