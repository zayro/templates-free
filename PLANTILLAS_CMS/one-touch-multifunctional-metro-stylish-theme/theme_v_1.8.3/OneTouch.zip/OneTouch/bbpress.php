<?php get_template_part('templates/header'); ?>

<div id="content" class="fifteen columns" role="main">
    <?php get_template_part('loop', 'page'); ?>
</div>

<?php get_template_part('templates/footer'); ?>

</body>
</html>