
<div class="entry-thumb">
    <?php the_content(); ?>
</div>
