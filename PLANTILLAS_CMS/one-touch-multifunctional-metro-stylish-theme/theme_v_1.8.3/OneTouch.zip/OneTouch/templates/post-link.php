<div class="tile mini" style="background: #90a7b1; width: 100%; margin:0; float:none;">
    <a href="<?php echo get_the_content(); ?>"></a>
    <div class="text-big-center">
        <?php echo get_the_content(); ?>
    </div>
</div>
