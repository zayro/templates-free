
<?php get_template_part('templates/page', 'header_work'); ?>

<div class="row">
  <div id="portfolio-page" class="clearing-container">
      <?php get_template_part('templates/portfolio', 'single'); ?>
  </div>
</div>

