<?php
require_once "lib.php";

require_once "page.php";
require_once "postt.php";
require_once "portfolio.php";
