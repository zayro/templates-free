<?php
require_once 'page/page-metaboxes.php';