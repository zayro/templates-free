<?php get_template_part('templates/page', 'header'); ?>

<div id="content" class="row">

    <?php get_template_part('templates/content', get_post_format()); ?>

</div>


