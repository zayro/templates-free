<?php
/*
Template Name: HomePage Template
*/
?>

<?php get_template_part('templates/page', 'home'); ?>
