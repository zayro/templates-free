=== Pricing Table ===
Contributors: Shaon
Donate link: http://shaon.info 
Tags: pricing table, price table, special offer, discount offer, offer, page, posts, post, widget, plugins, plugin
Requires at least: 2.0.2
Tested up to: 3.4.2
License: GPL 

WordPress Pricing Table plugin will help you to generate pricing table in the easitest and dynamic way

== Description ==

WordPress Pricing Table plugin will help the admin to publish pricing table on WordPress page or post content.
WordPress Pricing Table plugin packed with all features you will ever need to build a pricing or features table for your products or services in the easiest way. 
Use simple short-code `[ahm-pricing-table id=999 template=template_name]` (999=use any table id here and replace template with valid template name "green" or "gray" ) inside page or post content to embed pricing table.
 

= Features =
* Drag and drop package(column) re-ordering
* Drag and drop feature(row)  re-ordering
* Unlimited package(column) support
* Featured Column option highlight best price package
* Tooltip support
* 2 diff table template "green" and "gray"
* Translation ready

 

== Installation ==

1. Upload `pricing-table` to the `/wp-content/plugins/`  directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Frequently Asked Questions ==

N/A


== Screenshots ==

1. Pricing Table
2. Pricing table admin
3. Pricing table embed code
4. Pricing Table Template 2 (thanks to red-team-design.com)



== Changelog ==

= 1.1.6 =
* New option added Hide "Detail" and "Price" row
* Explained how to add toop tip text

= 1.1.5 =
* Fixed missing metabox issue
* Added tooltip support

= 1.1.4 =
* fixed author uri issue

= 1.1.3 =
* fixed css with with table template

= 1.1.2 =
* fixed wp 3.4 compatibility issue

= 1.1.1 =
* added multilanguage support
* fixed css issue
* optimized css for green template

= 1.1.0 =
* fixed reset.css issue
* fixed html issue with green template
* adjusted issue with enqueue script

= 1.0.7 = 
* adjusted minor jQuery issue

= 1.0.6 =  
* New table template added

= 1.0.5 = 
* New column added to show short code

= 1.0.4 =
* Row drag and drop feature added
* column grad and drop feature added


= 1.0.3 =
* issues with table template price_table.php is fixed

= 1.0.2 =
* help section added with steps for creating pricing table


= 1.0.0 =

* initial release



== Arbitrary section ==

N/A



== A brief Markdown Example ==



== Upgrade Notice ==

N/A