  <?php   
    $data = get_post_meta($pid, 'pricing_table_opt',true);
    $featured=  get_post_meta($pid, 'pricing_table_opt_feature',true);  
    
?>

    <style> 
    #pricing-table {
      margin: 50px auto 50px auto;
      text-align: center;
      border: 1px solid #cecece;
      float: left;
      border-radius: 0;
    }

    #pricing-table .plan {
        font-size: 14px;
        background: #fff;      
        border-right: 1px solid #eeeeee;
        color: #676767;
        width: 170px;
        float: left;
        position: relative;
    }
    
     #pricing-table .plan:hover,  #pricing-table .plan:hover li,  #pricing-table .plan:hover .title-price,  #pricing-table .plan:hover .tab-price-bott span,  #pricing-table .plan:hover .title-price span {
         background: #19aed7;
         color: #fff;
    }
    #pricing-table #most-popular ul {
      border-bottom: 1px solid #f3f3f3;
    }


    /* --------------- */

    #pricing-table ul {
        margin: 20px 0 0 0;
        padding: 0;
        list-style: none;
    }

    #pricing-table li {
      border-top: 1px solid #f3f3f3;
      padding: 15px 0;
      font-size: 14px;
      font-weight: 300;
    }
    #pricing-table li:nth-child(2n) {
      background: #f3f3f3; /* Цвет фона */
    }
    
    /* --------------- */
        
    #pricing-table .signup {
      font-size: 14px;
      color: #fff;
      background: #343434;
      font-family: 'Source Sans Pro', 'Segoe UI', Tahoma, Arial, Helvetica, sans-serif;
      padding: 10px 25px;
      margin-bottom: 15px;
      display: inline-block;
    }
    #pricing-table #most-popular .signup {
      background: #19aed7;
      color: #fff;
    }
    #pricing-table #most-popular.signup:hover {
      background: #343434;
      color: #19aed7;
    }
    #pricing-table .signup:hover {
      background: #19aed7;
    }
    #pricing-table .plan:hover .signup {
      background: #343434;
    }
     #pricing-table .plan:hover .signup:hover {
      background: #343434;
      color: #fff;
    }
     #pricing-table #most-popular.plan:hover .signup {
      background: #343434;
      color: #fff;
    }


    
    /* --------------- */

    .pclear:before, .pclear:after {
      content:"";
      display:table
    }

    .pclear:after {
      clear:both
    }

    .pclear    {
      zoom:1
    }

    .title-price {
      font-size: 25px;
      font-family: 'Source Sans Pro', 'Segoe UI', Tahoma, Arial, Helvetica, sans-serif;
      font-weight: 300;
      background: #f3f3f3;
      padding: 20px 5px;
      margin: 10px;
      min-height: 145px;
    }
    .title-price div{
      font-size: 25px;

    }
    .title-price span {
      font-size: 40px;
      color: #19aed7;
      font-weight: 300;
      font-family: 'Source Sans Pro', 'Segoe UI', Tahoma, Arial, Helvetica, sans-serif;
    }
    .title-price .price {
      font-size: 40px;
      padding-top: 10px;
         }
    .tab-price-bott .price {
      font-weight: 300;
      font-family: 'Source Sans Pro', 'Segoe UI', Tahoma, Arial, Helvetica, sans-serif;
      font-size: 23px;
      margin: 20px;
    }
    .tab-price-bott   span {
      color: #19aed7;
    }

    </style>

<div style="clear: both;"></div>

<div id="pricing-table" class="pclear">
 <?php
    foreach($data as $key=> $value){
    ?>
    <div class="plan" <?php if($featured==$key){?> id="most-popular"<?php } ?> >
   
        <div class="title-price">
            <?php echo $key;?>
          <div class="price">$<span><?php echo $value['Price']; ?></span></div>
        </div>


      <ul>

          <?php foreach($value as $key1=>$value1){
          if(strtolower($key1)=='detail')
              echo "<li>".$value1."</li>";
          else if( strtolower($key1)!="button url" && strtolower($key1)!="button text" && strtolower($key1)!="price"){
              $value1 = explode("|",$value1);
              if($value1[1]!='')
                  echo "<li><a href='#' title='{$value1[1]}'>".$value1[0]."</a></li>";
              else
                  echo "<li>".$value1[0]."</li>";
          }
      }
          ?>

      </ul>

      <div class="tab-price-bott">
        <div class="price">$<span><?php echo $value['Price']; ?></span></div>
        <a class="signup" href="<?php echo $value['Button URL']?>"><?php echo $value['Button Text']?></a>
      </div>


    </div >
  <?php } ?>  
   
   

</div>


<!-- price table designed by red-team-design.com -->

