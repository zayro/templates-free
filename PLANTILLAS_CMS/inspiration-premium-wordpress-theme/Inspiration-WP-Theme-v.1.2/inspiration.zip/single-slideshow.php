<?php
  wp_redirect('/');
?>
