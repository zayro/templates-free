<?php
	get_template_part('gallery');
?>
