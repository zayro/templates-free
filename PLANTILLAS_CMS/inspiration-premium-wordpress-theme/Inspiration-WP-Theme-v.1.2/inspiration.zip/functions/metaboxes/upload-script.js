jQuery(document).ready(function() {
	jQuery('#upload_image_button1').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image1').val(imgurl);
			tb_remove();
		}

		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});
 
jQuery(document).ready(function() {
	jQuery('#upload_image_button2').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image2').val(imgurl);
			tb_remove();
		}
		
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});
 
jQuery(document).ready(function() {
	jQuery('#upload_image_button3').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image3').val(imgurl);
			tb_remove();
		}
		
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});
 
jQuery(document).ready(function() {
	jQuery('#upload_image_button4').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image4').val(imgurl);
			tb_remove();
		}
		
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});
 
jQuery(document).ready(function() {
	jQuery('#upload_image_button5').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image5').val(imgurl);
			tb_remove();
		}
		
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});
 
jQuery(document).ready(function() {
	jQuery('#upload_image_button6').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image6').val(imgurl);
			tb_remove();
		}
		
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});
 
jQuery(document).ready(function() {
	jQuery('#upload_image_button7').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image7').val(imgurl);
			tb_remove();
		}
		
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});
 
jQuery(document).ready(function() {
	jQuery('#upload_image_button8').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image8').val(imgurl);
			tb_remove();
		}
		
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});
 
jQuery(document).ready(function() {
	jQuery('#upload_image_button9').click(function() {
		window.send_to_editor = function(html) {
			imgurl = jQuery('img',html).attr('src');
			jQuery('#portfolio_image9').val(imgurl);
			tb_remove();
		}
		
		tb_show('', 'media-upload.php?post_id=1&amp;type=image&amp;TB_iframe=true');
		return false;
	});
});