<?php
	the_content();
?>
