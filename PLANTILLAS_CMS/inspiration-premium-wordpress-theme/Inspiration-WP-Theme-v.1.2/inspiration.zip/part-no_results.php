		<div id="content">
		<!--If no results are found-->
			<h2><?php _e('No Results Found', TEMPLATENAME); ?></h2>
			<p><?php _e('The page you requested could not be found. Try refining your search, or use the navigation above to locate the post.', TEMPLATENAME); ?></p>
		<!--End if no results are found-->
		</div>