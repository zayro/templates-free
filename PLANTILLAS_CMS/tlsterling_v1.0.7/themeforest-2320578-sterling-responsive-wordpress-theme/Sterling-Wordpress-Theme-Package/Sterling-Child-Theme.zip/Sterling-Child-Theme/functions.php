<?php 

/* Insert your custom functions here */

?>