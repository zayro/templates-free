We truly appreciate your Theme purchase!

Theme Support: http://support.truethemes.net

3rd Party Resources used:
- Misc. Icons: http://led24.de/iconset/ (http://twitter.com/gasyoun)