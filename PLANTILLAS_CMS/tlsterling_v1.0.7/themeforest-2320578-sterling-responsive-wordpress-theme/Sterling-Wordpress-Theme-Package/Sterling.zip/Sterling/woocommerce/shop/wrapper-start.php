<section class="small_banner">
<?php get_template_part('template-part-woocommerce-banner','childtheme'); ?>
</section>

<section id="content-container" class="clearfix tt-woocommerce">
	<div id="main-wrap" class="clearfix">
        <div class="page_content">