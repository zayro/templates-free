	</div><!-- END page_content -->
  
	<aside class="sidebar right-sidebar">
		<?php dynamic_sidebar("WooCommerce Sidebar"); ?>
	</aside><!-- END sidebar-->

</div><!-- END main-wrap -->