<?php
/**
 * Single Product Title
 */
?>
<h1 itemprop="name" class="product_title entry-title"><?php the_title(); ?></h1>