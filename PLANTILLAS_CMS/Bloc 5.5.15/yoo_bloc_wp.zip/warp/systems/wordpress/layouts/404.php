<div id="system">

	<h1 class="title"><?php _e('Error 404 - Not Found', 'warp'); ?></h1>
	<p><?php _e('The page you requested does not exist, or has been moved.', 'warp'); ?></p>

</div>