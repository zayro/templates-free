<?php echo $oldoutput; ?>

<p class="readmore">
    <a target="_blank" href="<?php echo $params['url'];?>" class="readmore"><?php _e('Read feed'); ?></a>
</p>