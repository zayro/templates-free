<?php
/**
* @package   Bloc
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// add links css class
$xml  =& $this->getHelper('xml');
$list = $xml->load($oldoutput, 'xhtml');

if ($ul = $list->document->getElement('ul')) {
    $ul->addAttribute('class', 'links');
    echo $ul->toString();
}