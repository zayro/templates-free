<?php
/**
* @package   Bloc
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// no direct access
die('Restricted access');

?>

Changelog
------------

5.5.15
^ Updated Warp framework to 5.5.24 / 5.5.25

5.5.14
^ Updated Warp framework to 5.5.23

5.5.13
^ Updated Warp framework to 5.5.22

5.5.12
^ Updated Warp framework to 5.5.21

5.5.11
^ Updated Warp framework to 5.5.20

5.5.10
^ Updated Warp framework to 5.5.18 / 5.5.19

5.5.9
^ Updated Warp framework to 5.5.17

5.5.8
^ Updated Warp framework to 5.5.16
^ Changed template dom ready event to use bind

5.5.7
^ Updated Warp framework to 5.5.15

5.5.6
^ Updated Warp framework to 5.5.14

5.5.5
^ Updated Warp framework to 5.5.13

5.5.4
^ Updated Warp framework to 5.5.12

5.5.3
^ Updated Warp framework to 5.5.11

5.5.2
^ Updated Warp framework to 5.5.10

5.5.1
^ Updated Warp framework to 5.5.9

5.5.0
+ Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note