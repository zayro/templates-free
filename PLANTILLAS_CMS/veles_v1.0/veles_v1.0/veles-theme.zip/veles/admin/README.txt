All questions and setup instructions please go to http://aquagraphite.com/2011/09/29/slightly-modded-options-framework/

@author - Syamil MJ
@author - URI http://aquagraphite.com
@title  - Slightly Modded Options Framework SMOF
@description - Options frameworks with improved aesthetics and added features
@version - 1.2
@license - GPLv2 (inherited) - free to use and abuse for either commercial or personal.