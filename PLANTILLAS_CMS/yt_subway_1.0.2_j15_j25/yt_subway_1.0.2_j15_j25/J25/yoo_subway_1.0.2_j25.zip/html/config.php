<?php
/**
* @package   yoo_subway
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// get config
require_once(dirname(dirname(__FILE__)).'/config.php');

// get warp
$warp = Warp::getInstance();