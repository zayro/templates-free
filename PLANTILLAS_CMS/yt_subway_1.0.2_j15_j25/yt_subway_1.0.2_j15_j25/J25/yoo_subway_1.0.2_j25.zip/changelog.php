<?php
/**
* @package   yoo_subway
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// no direct access
die('Restricted access');

?>

Changelog
------------

1.0.2
^ Updated menu icons and titles according to Warp 6.2
^ Updated wrapper box-sizing according to Warp 6.2

1.0.1
# Fixed page title style
+ Theme blog style does also work for ZOO blog

1.0.0
+ Initial Release



* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note