<jdoc:include type="message" />
<jdoc:include type="component" />